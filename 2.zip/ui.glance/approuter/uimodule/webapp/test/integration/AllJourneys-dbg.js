sap.ui.define([
  "sap/ui/test/Opa5",
  "ui/glance/test/integration/arrangements/Startup",
  "ui/glance/test/integration/BasicJourney"
], function(Opa5, Startup) {
  "use strict";

  Opa5.extendConfig({
    arrangements: new Startup(),
    pollingInterval: 1
  });

});
